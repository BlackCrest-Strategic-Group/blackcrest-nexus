# GovCon Supplier Engine

Qualified supplier discovery engine for GovCon AI. This service maps an item category to likely NAICS codes, then filters and ranks suppliers by:

- AS9100 certification
- ISO 9001 certification
- SAM registration
- Active SAM status
- Optional state
- Optional business type

## Run locally

```bash
npm install
npm run dev
```

Open:
- `http://localhost:3000`
- `http://localhost:3000/health`

## API routes

### Get categories
```bash
GET /api/suppliers/categories
```

### Get mapped NAICS for one category
```bash
GET /api/suppliers/naics-map/CNC%20Machining
```

### Search suppliers
```bash
POST /api/suppliers/search
Content-Type: application/json

{
  "itemCategory": "CNC Machining",
  "requireAS9100": true,
  "requireISO9001": true,
  "requireSAM": true,
  "activeSAMOnly": true,
  "state": "",
  "businessType": ""
}
```

## Scoring model

Weighted score:
- Item category match = 35%
- NAICS match = 25%
- AS9100 = 15%
- ISO 9001 = 10%
- SAM active = 15%

## Deploy to Render

1. Push this folder to GitHub.
2. In Render, create a new Web Service.
3. Connect the GitHub repo.
4. Use:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. Leave `PORT` unset in Render. Render injects it automatically.
6. Deploy.

## Files to merge into your existing GovCon repo

If you want this inside your current app instead of a separate repo, move these into your existing project:

- `src/routes/suppliers.js`
- `src/services/supplierService.js`
- `src/data/suppliers.json`
- `src/data/itemCategoryMappings.json`
- `public/index.html`
- `public/styles.css`
- `public/app.js`

Then in your existing `server.js`, mount:
```js
const supplierRoutes = require("./src/routes/suppliers");
app.use("/api/suppliers", supplierRoutes);
```

## Next upgrade you should do

Right now this uses seed data so you can push and demo immediately.

Next phase:
- replace `suppliers.json` with MongoDB
- connect SAM lookup
- connect certification registry ingestion
- add export to CSV
- add save supplier to opportunity
- add RFQ workflow
