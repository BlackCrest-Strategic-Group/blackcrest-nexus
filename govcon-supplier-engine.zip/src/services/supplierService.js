const suppliers = require("../data/suppliers.json");
const itemCategoryMappings = require("../data/itemCategoryMappings.json");

function normalize(value) {
  return String(value || "").trim().toLowerCase();
}

function getPossibleNaics(itemCategory) {
  const category = normalize(itemCategory);

  const exactMatch = itemCategoryMappings.find(
    (entry) => normalize(entry.itemCategory) === category
  );

  if (exactMatch) {
    return exactMatch.naicsCodes;
  }

  const partialMatches = itemCategoryMappings
    .filter((entry) => normalize(entry.itemCategory).includes(category) || category.includes(normalize(entry.itemCategory)))
    .flatMap((entry) => entry.naicsCodes);

  return [...new Set(partialMatches)];
}

function calculateCategoryScore(requestedCategory, supplierCategories = []) {
  if (!requestedCategory) return 0;

  const requested = normalize(requestedCategory);
  const normalizedSupplierCategories = supplierCategories.map(normalize);

  if (normalizedSupplierCategories.includes(requested)) return 1.0;

  const partial = normalizedSupplierCategories.some(
    (category) => category.includes(requested) || requested.includes(category)
  );

  return partial ? 0.7 : 0;
}

function calculateNaicsScore(possibleNaics = [], supplierNaics = []) {
  if (!possibleNaics.length) return 0;

  const supplierNaicsSet = new Set(supplierNaics.map(String));
  const exactMatchCount = possibleNaics.filter((code) => supplierNaicsSet.has(String(code))).length;

  if (exactMatchCount > 0) return 1.0;

  const prefixMatch = possibleNaics.some((requestedCode) => {
    const prefix = String(requestedCode).slice(0, 3);
    return supplierNaics.some((supplierCode) => String(supplierCode).startsWith(prefix));
  });

  return prefixMatch ? 0.5 : 0;
}

function calculateWeightedScore({
  categoryScore,
  naicsScore,
  as9100Match,
  iso9001Match,
  samMatch
}) {
  const score =
    categoryScore * 0.35 +
    naicsScore * 0.25 +
    as9100Match * 0.15 +
    iso9001Match * 0.10 +
    samMatch * 0.15;

  return Number((score * 100).toFixed(1));
}

function searchSuppliers(filters = {}) {
  const requestedCategory = filters.itemCategory || "";
  const possibleNaics = filters.possibleNaics?.length
    ? filters.possibleNaics
    : getPossibleNaics(requestedCategory);

  const requireAS9100 = filters.requireAS9100 === true;
  const requireISO9001 = filters.requireISO9001 === true;
  const requireSAM = filters.requireSAM === true;
  const activeSAMOnly = filters.activeSAMOnly === true;
  const locationState = normalize(filters.state);
  const businessType = normalize(filters.businessType);

  const results = suppliers
    .map((supplier) => {
      const categoryScore = calculateCategoryScore(requestedCategory, supplier.itemCategories);
      const naicsScore = calculateNaicsScore(possibleNaics, supplier.naicsCodes);

      const as9100Match = supplier.certifications?.as9100 ? 1 : 0;
      const iso9001Match = supplier.certifications?.iso9001 ? 1 : 0;
      const samMatch = supplier.sam?.registered && supplier.sam?.active ? 1 : 0;

      const matchScore = calculateWeightedScore({
        categoryScore,
        naicsScore,
        as9100Match,
        iso9001Match,
        samMatch
      });

      return {
        ...supplier,
        possibleNaics,
        scoring: {
          categoryScore,
          naicsScore,
          as9100Match,
          iso9001Match,
          samMatch,
          weightedScore: matchScore
        }
      };
    })
    .filter((supplier) => {
      if (requestedCategory && supplier.scoring.categoryScore === 0 && supplier.scoring.naicsScore === 0) {
        return false;
      }

      if (requireAS9100 && !supplier.certifications?.as9100) return false;
      if (requireISO9001 && !supplier.certifications?.iso9001) return false;
      if (requireSAM && !supplier.sam?.registered) return false;
      if (activeSAMOnly && !supplier.sam?.active) return false;
      if (locationState && normalize(supplier.location?.state) !== locationState) return false;

      if (businessType) {
        const supplierTypes = (supplier.businessType || []).map(normalize);
        if (!supplierTypes.includes(businessType)) return false;
      }

      return true;
    })
    .sort((a, b) => b.scoring.weightedScore - a.scoring.weightedScore);

  return {
    filtersApplied: {
      itemCategory: requestedCategory,
      possibleNaics,
      requireAS9100,
      requireISO9001,
      requireSAM,
      activeSAMOnly,
      state: filters.state || "",
      businessType: filters.businessType || ""
    },
    totalResults: results.length,
    results
  };
}

module.exports = {
  searchSuppliers,
  getPossibleNaics,
  itemCategoryMappings,
  suppliers
};
