const express = require("express");
const {
  searchSuppliers,
  getPossibleNaics,
  itemCategoryMappings,
  suppliers
} = require("../services/supplierService");

const router = express.Router();

router.get("/categories", (req, res) => {
  res.json({
    categories: itemCategoryMappings.map((entry) => ({
      itemCategory: entry.itemCategory,
      naicsCodes: entry.naicsCodes
    }))
  });
});

router.get("/all", (req, res) => {
  res.json({
    totalSuppliers: suppliers.length,
    results: suppliers
  });
});

router.post("/search", (req, res) => {
  const payload = req.body || {};
  const data = searchSuppliers(payload);
  res.json(data);
});

router.get("/search", (req, res) => {
  const {
    itemCategory = "",
    requireAS9100 = "false",
    requireISO9001 = "false",
    requireSAM = "false",
    activeSAMOnly = "false",
    state = "",
    businessType = ""
  } = req.query;

  const data = searchSuppliers({
    itemCategory,
    requireAS9100: requireAS9100 === "true",
    requireISO9001: requireISO9001 === "true",
    requireSAM: requireSAM === "true",
    activeSAMOnly: activeSAMOnly === "true",
    state,
    businessType
  });

  res.json(data);
});

router.get("/naics-map/:itemCategory", (req, res) => {
  const itemCategory = req.params.itemCategory;
  const possibleNaics = getPossibleNaics(itemCategory);

  res.json({
    itemCategory,
    possibleNaics
  });
});

module.exports = router;
