require("dotenv").config();

const path = require("path");
const express = require("express");
const cors = require("cors");

const supplierRoutes = require("./src/routes/suppliers");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get("/health", (req, res) => {
  res.json({
    ok: true,
    service: "govcon-supplier-engine",
    timestamp: new Date().toISOString()
  });
});

app.use("/api/suppliers", supplierRoutes);
app.use(express.static(path.join(__dirname, "public")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`GovCon Supplier Engine running on port ${PORT}`);
});
