async function loadCategories() {
  const response = await fetch("/api/suppliers/categories");
  const data = await response.json();

  const select = document.getElementById("itemCategory");
  select.innerHTML = '<option value="">Select a category</option>';

  data.categories.forEach((entry) => {
    const option = document.createElement("option");
    option.value = entry.itemCategory;
    option.textContent = entry.itemCategory;
    select.appendChild(option);
  });

  select.addEventListener("change", renderNaicsForSelectedCategory);
}

async function renderNaicsForSelectedCategory() {
  const itemCategory = document.getElementById("itemCategory").value;
  const naicsBox = document.getElementById("naicsBox");
  naicsBox.innerHTML = "";

  if (!itemCategory) return;

  const response = await fetch(`/api/suppliers/naics-map/${encodeURIComponent(itemCategory)}`);
  const data = await response.json();

  data.possibleNaics.forEach((code) => {
    const pill = document.createElement("div");
    pill.className = "pill";
    pill.textContent = code;
    naicsBox.appendChild(pill);
  });
}

function badge(label, isPositive) {
  return `<span class="badge">${label}: ${isPositive ? "Yes" : "No"}</span>`;
}

function renderResults(data) {
  const meta = document.getElementById("resultsMeta");
  const results = document.getElementById("results");

  meta.textContent = `${data.totalResults} supplier(s) found`;
  results.innerHTML = "";

  if (!data.results.length) {
    results.innerHTML = '<p class="muted">No suppliers matched the selected filters.</p>';
    return;
  }

  data.results.forEach((supplier) => {
    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
      <div class="card-header">
        <div>
          <h3>${supplier.vendorName}</h3>
          <div class="meta">${supplier.location.city}, ${supplier.location.state} • ${supplier.businessType.join(", ")}</div>
        </div>
        <div class="score">Match Score: ${supplier.scoring.weightedScore}</div>
      </div>

      <div class="badges">
        ${badge("AS9100", supplier.certifications.as9100)}
        ${badge("ISO 9001", supplier.certifications.iso9001)}
        ${badge("SAM Registered", supplier.sam.registered)}
        ${badge("SAM Active", supplier.sam.active)}
      </div>

      <p><strong>Categories:</strong> ${supplier.itemCategories.join(", ")}</p>
      <p><strong>NAICS:</strong> ${supplier.naicsCodes.join(", ")}</p>
      <p><strong>Contact:</strong> ${supplier.contact.name} | ${supplier.contact.title}</p>
      <p><strong>Email:</strong> <a href="mailto:${supplier.contact.email}">${supplier.contact.email}</a></p>
      <p><strong>Phone:</strong> ${supplier.contact.phone}</p>
      <p><strong>Website:</strong> <a href="${supplier.website}" target="_blank" rel="noreferrer">${supplier.website}</a></p>
      <p><strong>Sources:</strong> ${supplier.source.join(", ")}</p>
      <p class="muted">${supplier.notes}</p>
    `;

    results.appendChild(card);
  });
}

async function searchSuppliers() {
  const payload = {
    itemCategory: document.getElementById("itemCategory").value,
    state: document.getElementById("state").value.trim(),
    businessType: document.getElementById("businessType").value,
    requireAS9100: document.getElementById("requireAS9100").checked,
    requireISO9001: document.getElementById("requireISO9001").checked,
    requireSAM: document.getElementById("requireSAM").checked,
    activeSAMOnly: document.getElementById("activeSAMOnly").checked
  };

  const response = await fetch("/api/suppliers/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await response.json();
  renderResults(data);
}

document.getElementById("searchBtn").addEventListener("click", searchSuppliers);

loadCategories();
